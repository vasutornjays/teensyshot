

var baud = 115200;
var connId = [];
var initDone = 0;
var hexFile = 0;
var connected = 0;
var BlockName = 'page';
var BlockStartSign = 80;
var connectTo = 'KISSFCV2';
var targetSelection = 0;
var pages = [];
var fastMode = 1;
var fastmodewarningdone = 0;
var PageSize = 2048;
var FC_inESCFlasherMode = 0;
var writingDone = 1;

var RecBuffer = [];
var ByteArr = [];
var actPage = 0;
var isL4 = 0;

var PageVerification = [];
var PageConfirmation = [];
var PageErrors = [];
var WaitCounter = 0;
var bootloaderFound = 0;
var lookForBlCount = 0;
var writeModeDone = 0;
var bootloaderconFirm = 0;
var bootloaderNames = ['BootloaderFail','KISSFC v2 L4 Bootloader','KISSFC v2 F7 Bootloader'];
var foundBootloader = 0;
var resetToBlDone = 0;

function doOnload(){
	document.getElementById('doit').onclick = function(){
		writeFlash();
	}	
	
	document.getElementById('fastmodeOn').onchange = function(){
		if(this.checked){
			fastMode = 1;
			visibleLog('fast mode enabled');
		}else{
			fastMode = 0;
			visibleLog('fast mode disabled');	
		}
	}
	
	document.getElementById('source').addEventListener('change', function(evt){
		var fileLoaded = document.getElementById('source').value.split('\\');
		visibleLog('reading file: '+fileLoaded[fileLoaded.length-1])
		var reader = new FileReader();
		reader.onload = (function(theFile) {
			return function(e) {
				hexFile = e.target.result;
				parseHexFile();
			};
		})(evt.target.files[0]);

		reader.readAsText(evt.target.files[0]);		
	}, false);	
	
	document.getElementById('contype').onchange = function(){
		targetSelection = this.value;
		if(targetSelection == 0){
			connectTo = 'KISSFCV2';
			visibleLog('connect to a KISSFCV2');	
			document.getElementById('FastMode').style.display = "none";
		}
		if(targetSelection == 1){
			connectTo = 'KISSFC';
			visibleLog('connect to a KISSFC');	
			document.getElementById('FastMode').style.display = "block";
		}
		if(targetSelection == 2){
			connectTo = 'USBUART';
			visibleLog('connect to a USB-UART');
			document.getElementById('FastMode').style.display = "block";			
		}
	}
	
	document.getElementById('Bok').onclick = function(){
		document.getElementById('warning').style="display:none;"
	}		
	
}

function reset(){
	RecBuffer = [];
	actPage = 0;
	PageVerification = [];
	PageConfirmation = [];
	PageErrors = [];
	WaitCounter = 0;
	document.getElementById('source').value = '';
	bootloaderFound = 0;
	lookForBlCount = 0;
	writeModeDone = 0;
	resetToBlDone = 0;
}

function openPort(ports){
	document.getElementById('close').innerHTML = '';
	document.getElementById('comsel').innerHTML = '';
	
	var portwahl = document.createElement('select');
	portwahl.onchange = function(){
		openSerial(this.value);
	};
	portwahl.id = 'comselin';
	var portOpt = document.createElement('option');
	portOpt.value = '';
	portOpt.innerHTML = 'Select com Port';
	portwahl.appendChild(portOpt);
	
	for(var i in ports){
		var portOpt = document.createElement('option');
		portOpt.value = ports[i].path;
		portOpt.innerHTML = ports[i].path;
		portwahl.appendChild(portOpt);
	}
	document.getElementById('comsel').appendChild(portwahl);
	
	
	var refresh = document.createElement('input');
	refresh.type = 'button';
	refresh.value = 'Refresh';
	refresh.style.fontSize = '11px';
	refresh.style.width = '80px';
	refresh.onclick = function(){
		chrome.serial.getDevices(function(ports){
			openPort(ports);
		});
	}
	document.getElementById('close').appendChild(refresh);
}

function openSerial(portVal){
	
	if(connectTo == 'USBUART'){
		baud = 38400;
	}
	if(connectTo == 'KISSFC'){
		baud = 115200;
	}
	if(connectTo == 'KISSFCV2'){
		baud = 115200;
	}
	
	document.getElementById('contype').disabled = "disabled";
	document.getElementById('close').innerHTML = '';
	if(portVal == '') return;
	if(initDone == 0){
		chrome.serial.onReceive.addListener(serRead);
	}
	document.getElementById('comsel').removeChild(document.getElementById('comselin'));
        chrome.serial.connect(portVal, {bitrate: baud},serOpen);
	
	var closeComm = document.createElement('input');
	closeComm.type = 'button';
	closeComm.value = 'Close COM';
	closeComm.style.fontSize = '11px';
	closeComm.style.width = '80px';
	visibleLog('connected to '+portVal);
	closeComm.onclick = function(){
		chrome.serial.send(connId.connectionId,str2ab(''), closen);
	}
	document.getElementById('close').appendChild(closeComm);
	saledPort  = portVal;
	var opening = document.createElement('h2');
	opening.innerHTML ="selecting port: "+portVal;
	opening.id="opening";
	connected = 1;
	console.log(connectTo);
}

function serOpen(cInfo){
	connId = cInfo;
	if(document.getElementById('opening')){
		document.body.removeChild(document.getElementById('opening'));
	}
	document.getElementById('comsel').innerHTML = saledPort;
}

function serRead(info){
	if(info){
		if(info.data.byteLength > 0) {	
			var data = new Uint8Array(info.data);
			for(var i = 0; i< data.length; i++){
				if(BlockStartSign == 80){
					RecBuffer.push(data[i]);
				}else{ 
					if( data[i] == 'A'.charCodeAt(0) && connectTo == 'KISSFC' && writeModeDone == 1){
						writeModeDone = 2;
						FC_inESCFlasherMode = 1;
						visibleLog('get ESC\'s to BL mode');
						setTimeout(function(){
							if(writing == 1){
								actPage = pages.length;
								useTimeout = 1800;
								WritePage();
							}else visibleLog('Stopped');
						},2500);
					}
				}
			}
		}
	}
}

function Write(data){
	writingDone = 0;
	chrome.serial.send(connId.connectionId, str2ab(data), onWrite);
}

function onWrite(){
	writingDone = 1;
}

function closen(){
	FC_inESCFlasherMode = 0;
	document.getElementById('contype').removeAttribute("disabled");
	chrome.serial.disconnect(connId.connectionId, function(){chrome.serial.getDevices(function(ports){
		openPort(ports);
	});});
	visibleLog('com closed');
	connected = 0;
}

function onFlush(){
	
}


function getA2sign(numb){
	return String.fromCharCode(numb);
}


onload = function(){
	doOnload();
	chrome.serial.getDevices(function(ports){
		openPort(ports);
	});
}

onclose = function(){
	chrome.serial.disconnect(connId.connectionId, function(){});
	
};



function update_crc8(crc, crc_seed){
	crc_u = crc;
	crc_u ^= crc_seed;
	for ( i=0; i<8; i++){
		crc_u = ( crc_u & 0x80 ) ? 0x7 ^ ( crc_u << 1 ) : ( crc_u << 1 );
		if(crc_u > 256) crc_u -= 256;
	}
	return (crc_u);
}

function visibleLog(line){
	document.getElementById('ConSole'). innerHTML+='<br \>'+line;
	document.getElementById('ConSole').scrollTop = document.getElementById('ConSole').scrollHeight;
}

function visibleLogInline(line){
	document.getElementById('ConSole'). innerHTML+= line;
}

var TopPage = 0;
function parseHexFile(){
	ByteArr = [];
	pages = [];
	var hexFileArr = hexFile.replace(/(?:\r\n|\r|\n)/g, '').split(':');
	var adressCounter = 0
	for(var i = 0; i < hexFileArr.length;i++){
		var lineArr = hexFileArr[i].split("");
		var hexLineAdress = parseInt('0x'+lineArr[2]+''+lineArr[3]+''+lineArr[4]+''+lineArr[5]);
		if(i == 2){
			adressCounter = hexLineAdress;
			visibleLog('hex start at: '+adressCounter);
		}
		if(i == 3){
			if(parseInt(lineArr[3]) == 4){
				BlockName = 'page';
				BlockStartSign = 70;
				isL4 = 0;
			}else if(parseInt(lineArr[3]) == 8){
				BlockName = 'block';
				BlockStartSign = 69;	
				isL4 = 0;
			}else if(parseInt(lineArr[2]) == 1){
				BlockName = 'block';
				BlockStartSign = 69;	
				isL4 = 1;
			}else if(parseInt(lineArr[2]) == 2){
				BlockName = 'page';
				bootloaderconFirm = 1;
				BlockStartSign = 80;	
			}else if(parseInt(lineArr[2]) == 8){
				BlockName = 'block';
				bootloaderconFirm = 2;
				BlockStartSign = 80;	
			}else{
				visibleLog('this hexfile cant be loaded as it is not bootloder conform');
				pages = [];
				return;
			}
		}
		if(parseInt('0x'+lineArr[6]+lineArr[7]) == 0){
			if(hexLineAdress < adressCounter) hexLineAdress = adressCounter;
			while(adressCounter < hexLineAdress){
				ByteArr.push(255);
				adressCounter++;
			}
			for(var y=8;y<lineArr.length-2;y+=2){
				adressCounter++;
				ByteArr.push(parseInt('0x'+lineArr[y]+lineArr[y+1]));
			}
		}
	}
	var pagecounter = 0;
	var pageBytecounter = 0;
	if(BlockStartSign == 80){ // KISSFCv2
		// resize to full pages
		var fittingpages = Math.ceil(ByteArr.length/PageSize);
		var leftBytes = (fittingpages*PageSize)-(ByteArr.length);
		visibleLog('loaded: '+ByteArr.length+' bytes');
		for(var i = 0;i< leftBytes;i++){
			ByteArr.push(255);
		}
		visibleLog(BlockName+' conform: '+ByteArr.length+'bytes, '+ByteArr.length/PageSize+' '+BlockName+'s');		
		TopPage = ByteArr.length/PageSize;
		
		// format 80, pageIndexLowByte, pageIndexHighByte,isFirstPageByte,2048bytes content,0
		for(var i = 0; i< ByteArr.length; i++){
			if(pageBytecounter == 0){
				pages[pagecounter] = [];
				
				pages[pagecounter].push(BlockStartSign);
				
				pages[pagecounter].push((pagecounter&0xFF));
				pages[pagecounter].push((pagecounter>>8));
				
				if(pagecounter < (ByteArr.length/PageSize)-1){
					pages[pagecounter].push(0);
				}else{
					pages[pagecounter].push(255);			
				}
			}
			pages[pagecounter].push(ByteArr[i]);	
			pageBytecounter++;
			if(pageBytecounter == PageSize){
				pageBytecounter = 0;
				pages[pagecounter].push(0);		
				pagecounter++;
			}
		}
	}else{ // ESC's
		var crc = 0;
		
		// resize to full pages
		var fittingpages = Math.ceil(ByteArr.length/64);
		var leftBytes = (fittingpages*64)-(ByteArr.length);
		visibleLog('loaded: '+ByteArr.length+' bytes');
		for(var i = 0;i< leftBytes;i++){
			ByteArr.push(255);
		}
		visibleLog(BlockName+' conform: '+ByteArr.length+'bytes, '+ByteArr.length/64+' '+BlockName+'s');
		
		for(var i = 0; i< ByteArr.length; i++){
			if(pageBytecounter == 0){
				pages[pagecounter] = [];
				crc = update_crc8(BlockStartSign, 0);
				pages[pagecounter].push(BlockStartSign);
				pages[pagecounter].push(BlockStartSign);
				pages[pagecounter].push(BlockStartSign);
				
				crc = update_crc8((pagecounter&0xFF), crc);
				pages[pagecounter].push((pagecounter&0xFF));
				pages[pagecounter].push((pagecounter&0xFF));
				pages[pagecounter].push((pagecounter&0xFF));
				
				crc = update_crc8((pagecounter>>8), crc);
				pages[pagecounter].push((pagecounter>>8));
				pages[pagecounter].push((pagecounter>>8));
				pages[pagecounter].push((pagecounter>>8));
				
				if(pagecounter < (ByteArr.length/64)-1){
					crc = update_crc8(0, crc);
					pages[pagecounter].push(0);
					pages[pagecounter].push(0);
					pages[pagecounter].push(0);
				}else{
					crc = update_crc8(255, crc);
					pages[pagecounter].push(255);
					pages[pagecounter].push(255);
					pages[pagecounter].push(255);				
				}
			}
			crc = update_crc8(ByteArr[i], crc);
			pages[pagecounter].push(ByteArr[i]);
			pages[pagecounter].push(ByteArr[i]);
			pages[pagecounter].push(ByteArr[i]);		
			pageBytecounter++;
			if(pageBytecounter == 64){
				pageBytecounter = 0;
				pages[pagecounter].push(crc);
				pages[pagecounter].push(crc);
				pages[pagecounter].push(crc);			
				pagecounter++;
			}
		}
	}
}

var useTimeout = 1800;

var writing = 0;
function writeFlash(){
	if(writing == 0){
		if(!connected){
			visibleLog('please connect to a com port.');
			return;
		}
		if(pages.length == 0){
			visibleLog('please select a valid hex file.');
			return;
		}
		if(connectTo != 'USBUART' && BlockStartSign != 80 && writeModeDone == 0){
			visibleLog('Setting KISS FC to ESC write mode');
			writeModeDone = 1;
			var InfoString = ['A'.charCodeAt(0)];
			Write(InfoString);
			visibleLog('waiting for FC');
			setTimeout(function(){
				if(FC_inESCFlasherMode == 0) visibleLog('got no answer. check your com port selection and see if you have the lastest KISSFC version.');
			},2000);
			writing = 1;
			document.getElementById('doit').value ="Stop";
			return;
		}
		writing = 1;
		document.getElementById('doit').value ="Stop";
		actPage = pages.length;
		useTimeout = 1800;
		if(BlockStartSign != 80) WritePage();
		else{
			RecBuffer = []; // empty rec buffer
			WritePageFC();
		}
	}else{
		reset();
		writing = 0;
		document.getElementById('doit').value ="Write flash";
	}
}


function WritePage(){
	RXhead = 0;
	var sendStr = '';
	
	actPage--;
	if(actPage >= 0){
		Write(pages[actPage]);
	}else{
		var startApp = [83,83,83];
		Write(startApp);
		visibleLog('done.');
		document.getElementById('doit').value ="Write flash";
		writing = 0;
		return;
	}
	visibleLog('sending '+BlockName+' '+(actPage+1)+' ('+((1000-Math.round(actPage/((pages.length)/1000)))/10)+'%)');
	
	if(writing == 1){
		setTimeout(function(){WritePage();},useTimeout);
		if(fastMode && isL4 == 0) useTimeout = 130;
		else if(fastMode && isL4 == 1) useTimeout = 68;
		else useTimeout = 500;
	}else{
		reset();
		writing = 0;
		document.getElementById('doit').value ="Write flash";
	}
}


/*
send datas to the FC BL

1. send the first page which is also the last page (highest number). it will erase the whole flash area
-> // format: 80, pageIndexLowByte, pageIndexHighByte, isFirstPageByte(255 for fisrt page, 0 for all others), 2048bytes content, 0

2. read and verify the page (it replays the whole page but with 1 at the end instead of 0)
    ... in case of no answer you can send the page again

3. send 81, 255, 255, 255, 0 to make it write the first sended page
    it will replay in case:
	flash written -> 81, 255, 255, 255, 1
	page buffer was empty (no page received before write command) -> 81, 255, 255, 255, 0
    ... in case of no answer you can repeat that command

*/


function WritePageFC(){
	if(bootloaderFound != 0){
		if(WaitCounter > 1000){
			visibleLog('Timeout fail!'+RecBuffer.length);
			reset();
			writing = 0;
			actPage = 0;
			document.getElementById('doit').value ="Write flash";
			return;
		}
		if(PageErrors[actPage] > 20){
			visibleLog('Communication fail!');
			reset();
			writing = 0;
			actPage = 0;
			document.getElementById('doit').value ="Write flash";
			return;
		}	
		if(actPage != TopPage){
			if(PageVerification[actPage] == 0){
				VerifyPage(actPage);
				return;
			}
			if(PageConfirmation[actPage] == 0){
				ReadConfirmation(actPage);
				return;
			}
		}

		actPage--;
		if(actPage >= 0){
			visibleLog('sending '+BlockName+' '+(actPage+1)+' ('+((1000-Math.floor(actPage/((pages.length)/1000)))/10)+'%)');
			WritePageToFC(actPage);
			PageErrors[actPage] = 0;
			WaitCounter = 0;
			visibleLog('Verification... ');
		}else{
			visibleLog('done.');
			reset();
			writing = 0;
			document.getElementById('doit').value ="Write flash";
			return;
		}
		
		if(writing == 1){
			setTimeout(function(){WritePageFC();},1);
		}else{
			reset();
			writing = 0;
			document.getElementById('doit').value ="Write flash";	
		}
	}else{
		if(resetToBlDone != 2) resetToBootloader();
		else askForBootloader();
	}
}

// step -1
function resetToBootloader(){
	if(resetToBlDone == 0){ // first look if we already in BLmode
		var requestBLthere = [81,255,255,125,0];
		Write(requestBLthere);
		resetToBlDone = 1;
		setTimeout(function(){resetToBootloader();},200);
	}else if(resetToBlDone == 1){
		if(RecBuffer.length >= 5 && RecBuffer[0] == 81 && RecBuffer[1] == 255 && RecBuffer[2] == 255 && RecBuffer[3] == 125 && (RecBuffer[4] == 1 || RecBuffer[4] == 2)){
			resetToBlDone = 2; // already in BL mode
			WritePageFC();
			return;
		}else{
			RecBuffer = [];
			visibleLog('Resetting FC...');
			var ResetCMD = ['O'.charCodeAt(0),'H'.charCodeAt(0),'R'.charCodeAt(0),'E'.charCodeAt(0),'S'.charCodeAt(0),'E'.charCodeAt(0),'T'.charCodeAt(0)];
			Write(ResetCMD);
			resetToBlDone = 2;
			setTimeout(function(){WritePageFC();},500);
		}
	}
}

//step 0

function askForBootloader(){
	if(lookForBlCount == 25){
		visibleLog('no bootloader found...');
		reset();
		writing = 0;
		document.getElementById('doit').value ="Write flash";	
		return;
	}else if(RecBuffer.length == 0){
		if(writingDone == 0) visibleLog('write error');
		var requestBLthere = [81,255,255,125,0];
		if(lookForBlCount == 0)visibleLog('looking for bootloader...');
		Write(requestBLthere);
		lookForBlCount++;		
	}else if(RecBuffer.length >= 5 && RecBuffer[0] == 81 && RecBuffer[1] == 255 && RecBuffer[2] == 255 && RecBuffer[3] == 125 && (RecBuffer[4] == 1 || RecBuffer[4] == 2)){
		bootloaderFound = RecBuffer[4];
		visibleLog(bootloaderNames[bootloaderFound]);
		if(bootloaderconFirm != bootloaderFound){
			visibleLog('the loaded hex file dont fits to the Bootloader');
			reset();
			return;
		}
		lookForBlCount = 0;
		WritePageFC();
		return;
	}else if(RecBuffer.length > 0 && RecBuffer[0] != 81){
		RecBuffer = [];
		visibleLog('unknowen answer');
		lookForBlCount++;	
	}
	setTimeout(function(){WritePageFC();},125);
}



// step1
function WritePageToFC(actPage){
	RecBuffer = [];
	PageVerification[actPage] = 0;
	PageConfirmation[actPage] = 0;
	Write(pages[actPage]);
}

//step2
function VerifyPage(actPage){
	if(RecBuffer.length >= PageSize+5){
		var VerificytionFailed = 0;
		for(i=0;i< (PageSize+4);i++){
			if(RecBuffer[i] != pages[actPage][i]){
				VerificytionFailed = 1;
				break;
			}
		}
		if(RecBuffer[PageSize+4] != bootloaderconFirm) VerificytionFailed = 1;
		
		RecBuffer = [];// empty Buffer
		if(VerificytionFailed == 1){
			visibleLogInline('failed!');
			PageErrors[actPage]++;
			//send wrong confirmation to make it listen to the page data again
			WritePageToFC(actPage); // send again
		}else{
			visibleLogInline('ok, ');
			PageVerification[actPage] = 1;
			var confirm = [81,255,255,255,0];
			Write(confirm);
			visibleLogInline('Confirmation... ');
		}
	}
	WaitCounter++;
	setTimeout(function(){WritePageFC();},1);
}

//step 3
function ReadConfirmation(actPage){
	if(RecBuffer.length >= 5){
		if(RecBuffer[0] == 81 && RecBuffer[1] == 255 && RecBuffer[2] == 255 && RecBuffer[3] == 255 && RecBuffer[4] == bootloaderconFirm){ // done
			visibleLogInline('ok.');
			PageConfirmation[actPage] = 1;
			RecBuffer = [];// empty Buffer
		}else if(RecBuffer[0] == 81 && RecBuffer[1] == 255 && RecBuffer[2] == 255 && RecBuffer[3] == 255 && RecBuffer[4] == 0){ // page buffer was empty
			visibleLogInline('failed!');
			PageErrors[actPage]++;
			PageVerification[actPage] = 0;//reset verification
			//send wrong confirmation to make it listen to the page data again
			WritePageToFC(delayedPage); // send again
		}else{
			visibleLogInline('failed!');
			PageErrors[actPage]++;
			var confirm = [81,255,255,255,0]; // ask again
			Write(confirm);
		}
	}
	WaitCounter++;
	setTimeout(function(){WritePageFC();},1);
}




//part of chrome serial lib
/**
Copyright 2012 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Author: Renato Mangini (mangini@chromium.org)
Author: Luis Leao (luisleao@gmail.com)
**/

var str2ab = function (arr) {
        var buf = new ArrayBuffer(arr.length);
        var bufView = new Uint8Array(buf);
        for (var i = 0; i < arr.length; i++) {
            bufView[i] = arr[i];
        }
        return buf;
};










