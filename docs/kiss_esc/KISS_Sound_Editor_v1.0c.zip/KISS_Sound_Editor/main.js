



onload = function(){
	doOnload();
}

function visibleLog(line){
	document.getElementById('ConSole'). innerHTML+='<br \>'+line;
	document.getElementById('ConSole').scrollTop = document.getElementById('ConSole').scrollHeight;
}

function visibleLogInline(line){
	document.getElementById('ConSole'). innerHTML+= line;
}
function visibleLogRed(line){
	document.getElementById('ConSole'). innerHTML+= '<br \><span style="color:red;">'+line+'</span>';
	document.getElementById('ConSole').scrollTop = document.getElementById('ConSole').scrollHeight;
}






var FileName = '';
var hexFile;
var hexStartAtAdress = 0;
var hexULBA = 0;
var ByteArr = [];
var SoundBankPosition = 0;
var SoundBankSize = 0;
var loadedSoundBank = [];
var soundPositions = [];
var soundLengths = [];
var aviableTime = 0.00;
var WAVfile;
var WAVfileID = 0;

function doOnload(){
	document.getElementById('source').addEventListener('change', function(evt){
		var fileLoaded = document.getElementById('source').value.split('\\');
		visibleLog('reading file: '+fileLoaded[fileLoaded.length-1]);
		FileName = fileLoaded[fileLoaded.length-1].substring(0, fileLoaded[fileLoaded.length-1].length-4);
		var reader = new FileReader();
		reader.onload = (function(theFile) {
			return function(e) {
				hexFile = e.target.result;
				parseHexFile();
			};
		})(evt.target.files[0]);

		reader.readAsText(evt.target.files[0]);		
	}, false);	
	
	document.getElementById('save').onclick = function(){
		saveHexFile();
	}
}


function parseHexFile(){
	hexFile;
	hexStartAtAdress = 0;
	ByteArr = [];
	SoundBankPosition = 0;
	SoundBankSize = 0;
	loadedSoundBank = [];
	soundPositions = [];
	soundLengths = [];
	aviableTime = 0.00;
	var hexFileArr = hexFile.replace(/(?:\r\n|\r|\n)/g, '').split(':');
	var adressCounter = 0;
	if(hexFileArr[1][1] == '2' && hexFileArr[1][7] == '4'){
		hexULBA = parseInt('0x'+hexFileArr[1][8]+''+hexFileArr[1][9]+''+hexFileArr[1][10]+''+hexFileArr[1][11]);
		visibleLog('hex ULBA: '+hexULBA);
	}
	for(var i = 0; i < hexFileArr.length;i++){
		var lineArr = hexFileArr[i].split("");
		var hexLineAdress = parseInt('0x'+lineArr[2]+''+lineArr[3]+''+lineArr[4]+''+lineArr[5]);
		if(i == 2){
			adressCounter = hexLineAdress;
			hexStartAtAdress = hexLineAdress;
		}
		if(parseInt('0x'+lineArr[6]+lineArr[7]) == 0){
			if(hexLineAdress < adressCounter) hexLineAdress = adressCounter;
			while(adressCounter < hexLineAdress){
				ByteArr.push(255);
				adressCounter++;
			}
			for(var y=8;y<lineArr.length-2;y+=2){
				adressCounter++;
				ByteArr.push(parseInt('0x'+lineArr[y]+lineArr[y+1]));
			}
		}
	}
	visibleLog('loaded : '+ByteArr.length+' bytes');
	visibleLog('hex start at: '+hexStartAtAdress);
	
	serachSoundBank();
}


function serachSoundBank(){
	for(i = 0; i < ByteArr.length; i++){
		if(getA2sign(ByteArr[i]) == 'S'){
			if(getA2sign(ByteArr[i+1]) == 'O' && getA2sign(ByteArr[i+2]) == 'U' && getA2sign(ByteArr[i+3]) == 'N' && getA2sign(ByteArr[i+4]) == 'D' && getA2sign(ByteArr[i+5]) == 'B' && getA2sign(ByteArr[i+6]) == 'A' && getA2sign(ByteArr[i+7]) == 'N' && getA2sign(ByteArr[i+8]) == 'K'){
				SoundBankPosition = i;
				SoundBankSize = ByteArr[i+9]*1000;
				visibleLog('found a soundbank with a size of '+(SoundBankSize-10)+' bytes');
				break;
			}
		}
	}
	
	
	if(SoundBankPosition == 0){
		visibleLogRed('no soundbank found in that hex file!');
		document.getElementById('editSoundContent').innerHTML = '';
		return;
	}
	
	
	for(i = 0; i < SoundBankSize;i++)loadedSoundBank.push(ByteArr[i+SoundBankPosition]);

	getSounds();
	visibleLog('available sound time '+aviableTime+' seconds');
	visibleLog(soundPositions.length+' sounds loaded with a total length of '+getTotaAudioLength()+' seconds');
	
	
	genEditorFields();
}

function getSounds(){
	var sounds = 0;
	var LengthIndicator = 10;
	soundLengths = [];
	soundPositions = [];
	while(LengthIndicator < SoundBankSize){
		var actSoundLength = (loadedSoundBank[LengthIndicator]<<16)+(loadedSoundBank[LengthIndicator+1]<<8)+(loadedSoundBank[LengthIndicator+2]);
		if(actSoundLength == 0){
			LengthIndicator = SoundBankSize;
			break;
		}
		soundLengths.push(actSoundLength);
		soundPositions.push(LengthIndicator+3);
		LengthIndicator += 3+actSoundLength;
	}
	aviableTime =  Math.round((((SoundBankSize-10)-(3*soundPositions.length))/8000)*100)/100;
}
function getTotaAudioLength(){
	var audioLength = 0.00;
	for(i = 0; i< soundLengths.length;i++) audioLength+= (soundLengths[i]/8000);
	return Math.round(audioLength*100)/100;
}
function getSingleAudioLength(soundPos){
	var audioLength = (soundLengths[soundPos]/8000);
	return Math.round(audioLength*100)/100;
}

function genEditorFields(){
	var EditContainer = document.getElementById('editSoundContent');
	EditContainer.innerHTML = '';
	for(var i = 0; i < soundPositions.length; i++){
		var SoundContainer = document.createElement('div');
		SoundContainer.id = 'soundEdit_'+i;
		
		var playSound = document.createElement('audio');
		ActSound = [];
		for(var y=0;y<soundLengths[i];y++){
			ActSound.push(loadedSoundBank[(soundPositions[i]+y)]);
		}
		
		playSound.setAttribute('controls', '');
		var SingleSound = document.createElement('source');
		var blob = new Blob([genWave(ActSound)]);
		SingleSound.src = URL.createObjectURL(blob);
		SingleSound.type = 'audio/wav';
		
		playSound.appendChild(SingleSound);
		
		SoundContainer.appendChild(playSound);
		
		//delete sound
		var ZeroSound = document.createElement('input');
		ZeroSound.type='button';
		ZeroSound.value = 'delete';
		ZeroSound.style.marginLeft = '10px';
		ZeroSound.style.position = 'absolute';
		ZeroSound.id = 'Z'+i;
		ZeroSound.onclick = function(){
			var delArr = [126,126];
			editSound(parseInt(this.id.replace(/Z/g,'')),delArr);
		}
		SoundContainer.appendChild(ZeroSound);
		
		
		//addSound
		var NewSound = document.createElement('input');
		NewSound.type='file';
		NewSound.name='wav'+i;
		NewSound.id='S'+i;
		NewSound.accept='wav';
		NewSound.style.position = 'absolute';
		NewSound.style.marginLeft = '75px';
		NewSound.addEventListener('change', function(evt){
			WAVfileID = parseInt(this.id.replace(/S/g,''));
			var reader = new FileReader();
			reader.onload = (function(theFile,id) {
				return function(e) {
					WAVfile = e.target.result;
					visibleLog(this.id);
					parseWAVFile();
				};
		})(evt.target.files[0]);

		reader.readAsBinaryString(evt.target.files[0]);			
	}, false);
		
		
		
		SoundContainer.appendChild(NewSound);
		
		EditContainer.appendChild(SoundContainer);
		
	}
	EditContainer.style.height = soundPositions.length*35+'px'
}


function editSound(SoundID,SoundArr){

	var newSoundsLength = SoundArr.length;
	
	var tempbank = ['S'.charCodeAt(0),'O'.charCodeAt(0),'U'.charCodeAt(0),'N'.charCodeAt(0),'D'.charCodeAt(0),'B'.charCodeAt(0),'A'.charCodeAt(0),'N'.charCodeAt(0),'K'.charCodeAt(0),SoundBankSize/1000];
	
	for(var i = 0; i < soundLengths.length; i++){
		if(i != SoundID){
			tempbank.push((soundLengths[i]>>16)&0xFF);
			tempbank.push((soundLengths[i]>>8)&0xFF);
			tempbank.push(soundLengths[i]&0xFF);
			for(var y=0;y< soundLengths[i];y++) tempbank.push(loadedSoundBank[soundPositions[i]+y]);
		}else{
			tempbank.push((newSoundsLength>>16)&0xFF);
			tempbank.push((newSoundsLength>>8)&0xFF);
			tempbank.push(newSoundsLength&0xFF);
			for(var y=0;y< newSoundsLength;y++) tempbank.push(SoundArr[y]);			
		}
	}
		
		
	
	if(tempbank.length > SoundBankSize){
		visibleLogRed('new sound is '+(Math.round(((SoundBankSize-tempbank.length)/8000)*100)/100)*-1+' seconds too long!');
		visibleLogRed('delete or shorten other sounds to get more time');
		visibleLogRed('and try again');
		return;
	}
	
	while(tempbank.length < loadedSoundBank.length) tempbank.push(0);
	
	loadedSoundBank = tempbank;
	
	
	getSounds();
	genEditorFields();
	
	visibleLog('sound '+(SoundID+1)+' changed');
	visibleLog('new available sound time '+(Math.round((aviableTime-getTotaAudioLength())*100)/100)+' seconds of total '+aviableTime+' seconds');
}









function getFileParts(offset,length){
	return WAVfile.slice(offset, offset+length);
}
function getIntFileParts(offset,length){
	var string = getFileParts(offset,length);
	var rInt = 0;
	for(var i = 0; i < string.length;i++){
		rInt |= string.charCodeAt(i)<<(i*8);
	}
	return rInt;
}

//WAVfile

function parseWAVFile(){
	
	//RIFF WAVE header
	var RIFF = getFileParts(0,4); // must be RIFF
	var dataSize = getIntFileParts(4,4)-8;
	var dataType = getFileParts(8,4);
	
	var fileformat = getIntFileParts(20,2); // must be PCM -> 1
	var channels = getIntFileParts(22,2); 
	var samplerate = getIntFileParts(24,2);
	var bytesPerSecond = getIntFileParts(28,4);
	var frameSize = getIntFileParts(32,2);
	var bitsPerSample = getIntFileParts(34,2);
	var blockLength = getIntFileParts(40,4); 
	if(blockLength > 0xFFFFFF || blockLength < 0) blockLength = WAVfile.length - 45;
	
	
	if(RIFF != "RIFF" || fileformat != 1){
		visibleLog('wrong file format, it must be a uncompressed WAV in PCM formar');
		return;
	}else{
		visibleLog(' ');
		visibleLogInline('loaded WAV file ');
		visibleLogInline('found: ');
		visibleLogInline(dataSize);
		visibleLogInline(' bytes of data in PCM format');
		visibleLog(' ');
		visibleLogInline('size: ');
		visibleLogInline(blockLength);
	}
	
	MonoSound = [];
	for(i = 44; i < blockLength; i += frameSize){
		if(bitsPerSample == 16){
			var singleSample = getIntFileParts(i,2);
			if(singleSample > 32767) singleSample = (65535-singleSample)*-1;
			singleSample += 32767;
			singleSample = singleSample>>8;
		}else{
			var singleSample = getIntFileParts(i,1);
		}
		MonoSound.push(singleSample); 
	}
	
	var TempResultingSound = [];
	var rateScale1 = Math.round(samplerate/8000);
	var rateScale2 = rateScale1-2;
	var scaleCorrect = 0;
	for(i = 0; i < MonoSound.length;i++){
		var rateScale = rateScale1;
		if(samplerate == 44100){
			if(scaleCorrect == 4){
				rateScale = rateScale2;
				scaleCorrect = 0;
			}else scaleCorrect++;
		}
		var LPF = MonoSound[i];
		for(y = i+1;y<i+rateScale;y++) LPF += MonoSound[y];
		TempResultingSound.push(Math.round(LPF/rateScale)); 
		i+=rateScale-1;
	}
	
	editSound(WAVfileID,TempResultingSound);
}


function addint16(val16){
	retString = String.fromCharCode(val16&0xFF)+''+String.fromCharCode((val16>>8)&0xFF);
	while(retString.length < 2) retString+= String.fromCharCode(0);
	return retString;
}
function addint32(val32){
	return addint16(val32>>16)+''+addint16(val32&0xFFFF);
}

function genWave(WavSound){
	
	var useBitrate = 8000;
	
	data = [];
	data.push('R'.charCodeAt(0));
	data.push('I'.charCodeAt(0));
	data.push('F'.charCodeAt(0));
	data.push('F'.charCodeAt(0));
	
	var newFilesize = (WavSound.length+36);
	data.push(newFilesize&0xFF);
	data.push((newFilesize>>8)&0xFF);
	data.push((newFilesize>>16)&0xFF);	
	data.push((newFilesize>>24)&0xFF);	
	
	data.push('W'.charCodeAt(0));
	data.push('A'.charCodeAt(0));
	data.push('V'.charCodeAt(0));
	data.push('E'.charCodeAt(0));	
	
	data.push('f'.charCodeAt(0));
	data.push('m'.charCodeAt(0));
	data.push('t'.charCodeAt(0));
	data.push(' '.charCodeAt(0));

	data.push(16);
	data.push(0);
	data.push(0);	
	data.push(0);	
	
	data.push(1);
	data.push(0);
	
	data.push(1);
	data.push(0);

	data.push(useBitrate&0xFF);
	data.push((useBitrate>>8)&0xFF);
	data.push((useBitrate>>16)&0xFF);	
	data.push((useBitrate>>24)&0xFF);	
	
	data.push(useBitrate&0xFF);
	data.push((useBitrate>>8)&0xFF);
	data.push((useBitrate>>16)&0xFF);	
	data.push((useBitrate>>24)&0xFF);	
	
	data.push(8);
	data.push(0);
	
	data.push(8);
	data.push(0);
	
	data.push('d'.charCodeAt(0));
	data.push('a'.charCodeAt(0));
	data.push('t'.charCodeAt(0));
	data.push('a'.charCodeAt(0));
	
	data.push(WavSound.length&0xFF);
	data.push((WavSound.length>>8)&0xFF);
	data.push((WavSound.length>>16)&0xFF);	
	data.push((WavSound.length>>24)&0xFF);	
	
	for(i=0;i<WavSound.length;i++) data.push(WavSound[i]);
	
	var FileContent = str2ab(data);
	return FileContent;
}


function decimalToPlainHex(d, padding) {
    var hex = Number(d).toString(16);
    padding = typeof (padding) === "undefined" || padding === null ? padding = 2 : padding;

    while (hex.length < padding) {
        hex = "0" + hex;
    }

    return hex.toUpperCase();
}

function saveHexFile(){
	var newHexContent = [];
	for(var i = 0; i < ByteArr.length; i++){
		if(i < SoundBankPosition || i >= (SoundBankPosition+loadedSoundBank.length)) newHexContent.push(ByteArr[i]);
		else newHexContent.push(loadedSoundBank[i-SoundBankPosition]);
	}
	var newHexMemAdress = hexStartAtAdress;
	var newHexString = '';
	var LastULBA = hexULBA;
	for(var i = 0; i < newHexContent.length; i+= 16){
		var lineCRC = 0;
		if(hexULBA != 0 && (i == 0 || hexULBA != LastULBA)){	
			newHexString += ':02000004';
			lineCRC += 6;	
			lineCRC += (hexULBA>>8)&0xFF;
			lineCRC += hexULBA&0xFF;
			newHexString += decimalToPlainHex(((hexULBA>>8)&0xFF),2);
			newHexString += decimalToPlainHex((hexULBA&0xFF),2);
			newHexString += decimalToPlainHex(((255-(lineCRC&0xFF))+1)&0xFF,2)+"\n";	
			LastULBA = hexULBA;
			lineCRC = 0;
		}
		lineCRC += 16+(newHexMemAdress>>8)+(newHexMemAdress&0xFF);
		newHexString+=':10'+decimalToPlainHex(newHexMemAdress, 4)+'00';
		for(var y=0;y<16;y++){
			if(typeof newHexContent[i+y] !== 'undefined'){
				lineCRC+= newHexContent[i+y]&0xFF;
				newHexString += decimalToPlainHex((newHexContent[i+y]&0xFF),2);
			}else{
				lineCRC+= 255&0xFF;
				newHexString += decimalToPlainHex(255&0xFF,2);				
			}
		}
		var lastMemAdress = newHexMemAdress;
		newHexMemAdress = (newHexMemAdress+16)&0xFFFF;
		if(lastMemAdress > newHexMemAdress) hexULBA++;
		
		newHexString+= decimalToPlainHex(((255-(lineCRC&0xFF))+1)&0xFF,2)+"\n";
	}
	newHexString+= ":00000001FF\n";
	SaveFile(newHexString, 'application/x-tex', 'hex');
}



//  'audio/x-wav'
function SaveFile(FileContent, Type, extension){
        var chosenFileEntry = null;

        var accepts = [{
            extensions: [extension]
        }];

        chrome.fileSystem.chooseEntry({
            type: 'saveFile',
            suggestedName: FileName+'_edit',
            accepts: accepts
        }, function(fileEntry) {
            if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError.message);
                return;
            }

            if (!fileEntry) {
                console.log('No file selected.');
                return;
            }

            chosenFileEntry = fileEntry;

            chrome.fileSystem.getDisplayPath(chosenFileEntry, function(path) {
                console.log('Export to file: ' + path);
            });

            chrome.fileSystem.getWritableEntry(chosenFileEntry, function(fileEntryWritable) {

                chrome.fileSystem.isWritableEntry(fileEntryWritable, function(isWritable) {
                    if (isWritable) {
                        chosenFileEntry = fileEntryWritable;
			
                        var blob = new Blob([FileContent], {
                            type: Type
                        });

                        chosenFileEntry.createWriter(function(writer) {
                            writer.onerror = function(e) {
                                console.error(e);
                            };

                            var truncated = false;
                            writer.onwriteend = function() {
                                if (!truncated) {
                                    truncated = true;
                                    writer.truncate(blob.size);
                                    return;
                                }
                                console.log('Config has been exported');
                            };

                            writer.write(blob);
                        }, function(e) {
                            console.error(e);
                        });
                    } else {
                        console.log('Cannot write to read only file.');
                    }
                });
            });
        });
    };



    
    
    
    
function getA2sign(numb){
	return String.fromCharCode(numb);
}

//part of chrome serial lib
/**
Copyright 2012 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Author: Renato Mangini (mangini@chromium.org)
Author: Luis Leao (luisleao@gmail.com)
**/


var str2ab = function (arr) {
        var buf = new ArrayBuffer(arr.length);
        var bufView = new Uint8Array(buf);
        for (var i = 0; i < arr.length; i++) {
            bufView[i] = arr[i];
        }
        return buf;
};










